var wysihtml5Editor = $('#id_hom_content').wysihtml5().data("wysihtml5").editor;
wysihtml5Editor.composer.commands.exec("bold");
