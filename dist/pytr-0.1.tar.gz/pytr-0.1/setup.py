from distutils.core import setup

setup(
    name='pytr',
    version='0.1',
    packages=['src', 'src.blog'],
    url='http://www.pytr.org',
    license='GPL',
    author='Halit Alptekin',
    author_email='info@halitalptekin.com',
    description='Another Django Project'
)
