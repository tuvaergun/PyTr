PyTr
========
Another Django project.

Installation
------------
You can install **pytr** ``pip`` or ``easy_install``. If you want to
fork and develop the project, create a virtual environment and install it
with::

    python setup.py install

Authors
-------
Halit Alptekin, <info[@]halitalptekin.com>

Todo
----
Error messages<br>
Link application<br>
Mobil theme<br>
Seo application<br>
Hard code removing<br>
Template dir moving and other templates add<br>
Meta code<br>